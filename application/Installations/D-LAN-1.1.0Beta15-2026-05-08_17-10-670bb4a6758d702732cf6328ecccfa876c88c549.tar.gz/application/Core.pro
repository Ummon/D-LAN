TEMPLATE = subdirs
CONFIG += ordered
MAKEFILE = Makefile-Core
SUBDIRS = Common \
   Common/LogManager \
   Core/FileManager \
   Core/PeerManager \
   Core/UploadManager \
   Core/DownloadManager \
   Core/NetworkListener \
   Core/RemoteControlManager \
   Core

TRANSLATIONS = translations/d_lan_core.fr.ts \
   translations/d_lan_core.ko.ts
CODECFORTR = UTF-8
